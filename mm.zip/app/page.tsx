import { AboutSection } from "@/components/about-section";
import { CredibilityStrip } from "@/components/credibility-strip";
import { Footer } from "@/components/footer";
import { HeroSection } from "@/components/hero-section";
import { ProcessSection } from "@/components/process-section";
import { PurposeBand } from "@/components/purpose-band";
import { RequestForm } from "@/components/request-form";
import { ServicesSection } from "@/components/services-section";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-white text-[#111827]">
      <HeroSection />
      <CredibilityStrip />
      <AboutSection />
      <ServicesSection />
      <PurposeBand />
      <ProcessSection />
      <RequestForm />
      <Footer />
    </main>
  );
}
