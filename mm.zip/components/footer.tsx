import { Logo } from "./logo";

export function Footer() {
  return (
    <footer className="bg-[#07111f] px-6 py-12 text-white lg:px-8">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 md:flex-row md:items-center md:justify-between">
        <Logo />

        <div className="text-sm leading-7 text-white/55 md:text-right">
          <p>Professional property, land, estate, and asset valuation services.</p>
          <p>� {new Date().getFullYear()} Idoko C. Idoko Valuations. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
