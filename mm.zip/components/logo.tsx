export function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="relative flex h-12 w-12 items-center justify-center overflow-hidden rounded-2xl bg-[#c99b42] shadow-lg shadow-black/20">
        <svg viewBox="0 0 64 64" className="h-10 w-10" aria-hidden="true">
          <path
            d="M14 50V24L32 12l18 12v26"
            fill="none"
            stroke="#07111f"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M23 50V31h18v19"
            fill="none"
            stroke="#07111f"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M18 50h28"
            stroke="#07111f"
            strokeWidth="4"
            strokeLinecap="round"
          />
          <path
            d="M32 12v38"
            stroke="#07111f"
            strokeWidth="3"
            strokeLinecap="round"
            opacity="0.35"
          />
        </svg>
      </div>

      <div className="leading-tight">
        <p className="text-lg font-black uppercase tracking-[-0.03em] text-white">
          Idoko C. Idoko
        </p>
        <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-amber-200/80">
          Valuations
        </p>
      </div>
    </div>
  );
}
